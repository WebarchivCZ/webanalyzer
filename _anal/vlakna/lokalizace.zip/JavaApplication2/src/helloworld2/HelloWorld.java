/*
 * HelloWorld.java
 *
 * Created on 21. březen 2007, 12:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package helloworld2;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.TimeZone;

public class HelloWorld {
    
    public static void main(String[] args) {
        ResourceBundle bundle = ResourceBundle.getBundle("helloworld2/Bundle");
        System.err.println(bundle.getString("Hello_world"));
        
        Date d = new Date();
        
        DateFormat dateFormat = DateFormat.getDateTimeInstance();

        System.out.println(dateFormat.format(d));

        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        System.out.println(dateFormat.format(d));

        Locale.setDefault(Locale.US);
        dateFormat = DateFormat.getDateTimeInstance();

        System.out.println(dateFormat.format(d));

        Currency currency = Currency.getInstance("USD");
        
        DecimalFormat format = 
                (DecimalFormat) NumberFormat.getCurrencyInstance();
        format.setCurrency(currency);
        System.out.println(format.format(100.20));
        Locale.setDefault(new Locale("cs","CZ"));

        format = 
                (DecimalFormat) NumberFormat.getCurrencyInstance();
        format.setCurrency(currency);
        System.out.println(format.format(100.20));

    }
    
}
