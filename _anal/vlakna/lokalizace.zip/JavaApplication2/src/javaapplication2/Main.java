/*
 * Main.java
 *
 * Created on 7. březen 2007, 12:27
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication2;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 *
 * @author xpavlov
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }

    static private DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    
    public static Date stringToDate(String s) {
        try {
            return format.parse(s);
        } catch (ParseException ex) {
            throw new RuntimeException(ex);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Date d1 = stringToDate("2007-01-01");
        Date d2 = stringToDate("2007-01-05");
        System.out.println(d1);
        System.out.println(d2);
    }
    
}
