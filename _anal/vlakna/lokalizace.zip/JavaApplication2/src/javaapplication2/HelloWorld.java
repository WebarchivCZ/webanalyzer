/*
 * HelloWorld.java
 *
 * Created on 21. březen 2007, 10:49
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication2;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author xpavlov
 */
public class HelloWorld {
        
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ResourceBundle bundle = ResourceBundle.getBundle("javaapplication2/Bundle");
        System.err.println(bundle.getString("Hello_world"));
        System.err.println("Nazdar světe");
        
        Date d = new Date();
        System.out.println(d);
        DateFormat format = new SimpleDateFormat();
        System.out.println(format.format(d));
        
        DecimalFormat numberFormat = 
                (DecimalFormat) NumberFormat.getCurrencyInstance();       
        numberFormat.setCurrency(Currency.getInstance("JPY"));
        System.out.println(numberFormat.format(100000000.20));

        Locale.setDefault(Locale.US); 
        
        numberFormat = 
                (DecimalFormat) NumberFormat.getCurrencyInstance();       
        numberFormat.setCurrency(Currency.getInstance("JPY"));
        System.out.println(numberFormat.format(100000000.20));

        Locale.setDefault(Locale.JAPAN); 
        
        numberFormat = 
                (DecimalFormat) NumberFormat.getCurrencyInstance();       
        numberFormat.setCurrency(Currency.getInstance("JPY"));
        System.out.println(numberFormat.format(100000000.20));
        
    }
    
}
